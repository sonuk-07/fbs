package bcu.cmp5332.bookingsystem.model;

public enum FlightType {
    BUDGET, COMMERCIAL
}

